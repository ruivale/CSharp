using System;

public class TestVerbatimStrings{

	public static void Main(){

		string test;
		test=@"c:\tEST\TEST.doc"; 
		Console.WriteLine(test);
		
		string test2;
		test2="c:\\tEST\\TEST.doc";
		Console.WriteLine(test2);

		//  @"c:\tEST\TEST.doc" is same as  "c:\\tEST\\TEST.doc"
		

	}
}