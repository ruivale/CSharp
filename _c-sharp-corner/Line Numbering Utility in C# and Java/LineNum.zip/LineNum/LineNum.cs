/**
*
* @author Ashish Banerjee , 5-may-2001
*/ 
/*
 (c) Osprey Software Technology P. Ltd., 2001, All rights reserved.
      http://www.ospreyindia.com
 ============================================================================
             The Osprey Open Source Software License, Version 1.1
      (Adapted from Apache Software License, V 1.1 [http://www.apache.org])
 ============================================================================
      
 Redistribution and use in source and binary forms, with or without modifica-
 tion, are permitted provided that the following conditions are met:
 
 1. Redistributions of  source code must  retain the above copyright  notice,
    this list of conditions and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.
 
 3. The end-user documentation included with the redistribution, if any, must
    include  the following  acknowledgment:  "This product includes  software
    developed  by the Osprey Software Technology P. Ltd.  (http://www.ospreyindia.com/)."
    Alternately, this  acknowledgment may  appear in the software itself,  if
    and wherever such third-party acknowledgments normally appear.
 
 4. The names "Osprey" and "Osprey Software Technology" must not be used to
    endorse  or promote  products derived  from this  software without  prior
    written permission. For written permission, please contact
    mail@ospreyindia.com.
 
 5. Products  derived from this software may not  be called "Osprey", nor may
    "Osprey" appear  in their name,  without prior written permission  of the
    Osprey Software Technology.
 
 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS  FOR A PARTICULAR  PURPOSE ARE  DISCLAIMED.  IN NO  EVENT SHALL  THE
 OSPREY SOFTWARE TECHNOLOGY  OR ITS CONTRIBUTORS  BE LIABLE FOR  ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL  DAMAGES (INCLU-
 DING, BUT NOT LIMITED TO, PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES; LOSS
 OF USE, DATA, OR  PROFITS; OR BUSINESS  INTERRUPTION)  HOWEVER CAUSED AND ON
 ANY  THEORY OF LIABILITY,  WHETHER  IN CONTRACT,  STRICT LIABILITY,  OR TORT
 (INCLUDING  NEGLIGENCE OR  OTHERWISE) ARISING IN  ANY WAY OUT OF THE  USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
using System;
using System.IO;
using System.Text;

namespace com.ospreyindia.util {
    public class LineNum {
        private LineNum() {} // no instance allowd

        public static void Main(string[] args)  {
            if(args.Length != 1) {
               Console.WriteLine("LineNum <C# source file>"); 
               Environment.Exit(1);
            }
            LineCount cnt = new LineCount(args[0]);
            int max = MaxPadCount(cnt.GetLines());

            StreamReader rdr = new StreamReader(new FileStream(args[0], FileMode.Open));
            NumGen(max, rdr);
            rdr.Close();

            
        } // END Main
        public static int MaxPadCount(int lines) {
            return lines.ToString().Length;
        }
        /** generates line  numbers and outputs to standard out (stdio)*/
        public static void NumGen(int max, StreamReader inr) {
              string ln;
              Padder pad = new Padder('0', max);
              int cnt = 0;
              while((ln = inr.ReadLine()) != null)
                 Console.WriteLine((pad.Pad(++cnt)+" "+ln));
        }


    } // END class LineNum
    
    public class Padder {
       public Padder(char padChar, int maxPad) {
          this.maxPad =  maxPad;
          StringBuilder buf = new  StringBuilder(maxPad);
          for(int i=0; i < maxPad;i++)
              buf.Append(padChar);

          pads = buf.ToString();
       }
       public string Pad(int inp) {
          return Pad(inp.ToString());
       }
       public string Pad(string inp) {
          string ret = inp; 
          if((inp != null) && (inp.Length < maxPad)) {
               ret = pads.Substring(0,(maxPad - inp.Length)) + inp;
          }

          return ret;
       }
       private int maxPad;
       private string pads;
    } // END class Padder

    public class LineCount {
       public LineCount(string fileName) {
          fname = fileName;
       }

       public int GetLines() {
          StreamReader rdr = new StreamReader(new FileStream(fname,FileMode.Open));
          int ret = 0;
          while(rdr.ReadLine() != null)
            ret++;
          rdr.Close();

          return ret;
       }

       private String fname;

    } // END class LineCount

} // END namespace
