namespace PROINFO.WebService.Data
{
    using System;
    using System.Collections;
    using System.Configuration;
    using System.ComponentModel;
    using System.Data;
	using System.Data.SQL;
    using System.Diagnostics;
    using System.Web;
    using System.Web.Services;

    /// <summary>
    ///    Summary description for WS.
    /// </summary>
    public class WS : System.Web.Services.WebService
    {
        public WS()
        {
            //CODEGEN: This call is required by the ASP+ Web Services Designer
            InitializeComponent();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
        }
		// Here starts the example code
		public struct sCustomers
		{
			public String sCustomerID;
			public String sCompanyName;
			public String sContactName;
			public String sContactTitle;
			public String sAddress;
			public String sCity;
			public String sRegion;
			public String sPostalCode;
			public String sCountry;
			public String sPhone;
			public String sFax;
		}
		[WebMethod(Description="ADO 2.6 WebMethod Example")]
		public sCustomers[] GetCustomersOld()
		{
			ADODB.Connection cn = new ADODB.Connection();
			ADODB.Recordset rs = new ADODB.Recordset();
			String strSQL;
			int intRC;
			int intCnt;

			strSQL = "SELECT * FROM Customers";
			cn.Open("Provider=SQLOLEDB; Data Source=SERVER; Initial Catalog=Northwind;", "sa", null, 0);
			rs.Open(strSQL, cn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly, 0);

			intRC = rs.RecordCount;
			if (intRC < 1)
			{
				return null;
			}

			sCustomers[] c = new sCustomers[intRC];
			rs.MoveFirst();
			intCnt = 0;
			while (!rs.EOF)
			{
				c[intCnt].sCustomerID = rs.Fields["CustomerID"].Value.ToString();
				c[intCnt].sCompanyName = rs.Fields["CompanyName"].Value.ToString();
				c[intCnt].sContactName = rs.Fields["ContactName"].Value.ToString();
				c[intCnt].sContactTitle = rs.Fields["ContactTitle"].Value.ToString();
				c[intCnt].sAddress = rs.Fields["Address"].Value.ToString();
				c[intCnt].sCity = rs.Fields["City"].Value.ToString();
				c[intCnt].sRegion = rs.Fields["Region"].Value.ToString();
				c[intCnt].sPostalCode = rs.Fields["PostalCode"].Value.ToString();
				c[intCnt].sCountry = rs.Fields["Country"].Value.ToString();
				c[intCnt].sPhone = rs.Fields["Phone"].Value.ToString();
				c[intCnt].sFax = rs.Fields["Fax"].Value.ToString();
				rs.MoveNext();
				intCnt++;
			}
			return c;
		}
		[WebMethod(Description="ADO.NET WebMethod Example")]
		public DataSet GetCustomersNew()
		{
			DataSet ds = new DataSet();

			SQLConnection cn = new SQLConnection("localhost", "sa", "", "Northwind");
			cn.Open();

			SQLDataSetCommand cm = new SQLDataSetCommand("SELECT * FROM Customers", cn);
			cm.FillDataSet(ds, "Customers");

			return ds;
		}
    }
}
