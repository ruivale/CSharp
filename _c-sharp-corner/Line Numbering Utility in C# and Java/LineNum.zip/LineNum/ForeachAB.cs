/** Ashish Banerjee -- test for each 
NOTE: This example will not interop with VB.NET
*/

using System;

public class TestForeach
{
public class CollAndEnum
{
  public CollAndEnum(int times, int seed)
  {
    iter = times;
    rand = new Random(seed);
  }
  // Collection 
  public CollAndEnum GetEnumerator()
  {
     Console.WriteLine(" [call: GetEnumerator]");
     return this;
  }
  //--- enum methods 
  public bool MoveNext() 
  {
    Console.WriteLine(" [call: MoveNext] ");
    return (i++ < iter); 
  }
  public int Current 
  {
     get
     {
       Console.Write(" [call: Current] ");
       return rand.Next();
     }
  }
  private int iter,i=0;
  private Random rand;
}
public static void Main(String [] args)
{
   /* foreach */
   Console.WriteLine("Foreach: start");
   CollAndEnum a = new CollAndEnum(3,1234);
   foreach(int i in a)
   {
      Console.WriteLine(i);
   }
   Console.WriteLine("Foreach: END");
   /* do while ----- ACHIEVES THE SAME RESULT AS FOREACH ------*/
   Console.WriteLine("***WHILE: start***");
    
   //CollAndEnum b = new CollAndEnum(3,1234); // same effect as next line
   
   CollAndEnum b = (new CollAndEnum(3,1234)).GetEnumerator();
   while(b.MoveNext())
   {
     Console.WriteLine(b.Current); 
   }
   
   Console.WriteLine("***WHILE: end***");
}
}