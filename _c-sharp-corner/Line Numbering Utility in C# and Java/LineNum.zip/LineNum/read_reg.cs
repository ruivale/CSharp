//Create two RegistryKey variables.
//create object od sealed class as shown below with first parameter as HKEY (main root key name) and second as "" for local machine.
//create sub key from where one would like to read information.
//Use getvalue for reading data for a particular node key information.
	//here DSN,Server,Password are nodes.

//following text is a actual registry information.
//copy peast this content in text file with extention .reg.
//execute it and reun this code.
 
/*Windows Registry Editor Version 5.00

[HKEY_CURRENT_USER\Software\TAW\BSE]
"DSN"="TAWReports"
"User"="TAW1"
"Password"="taw1.1"
"Server"="dbserver"
"IP"=""
*/

namespace CONAPP
{
    using System;
	using Microsoft.Win32;
    
    public class Class1
    {
        public Class1()
        {
            //
            // TODO: Add Constructor Logic here
            //
        }

        public static int Main(string[] args)
        {			
			
			RegistryKey SUBKEY; 
			RegistryKey TAWKAY  = RegistryKey.OpenRemoteBaseKey(Microsoft.Win32.RegistryHive.CurrentUser,"");
			string subkey = "Software\\TAW\\BSE";
			SUBKEY = TAWKAY.OpenSubKey(subkey);		
			object dsn = SUBKEY.GetValue("DSN");
			object user = SUBKEY.GetValue("user");
			object password = SUBKEY.GetValue("password");
			object server = SUBKEY.GetValue("server");
            return 0;
        }
    }
}

