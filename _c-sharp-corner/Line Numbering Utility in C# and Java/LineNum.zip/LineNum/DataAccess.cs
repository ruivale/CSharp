using System;
using System.WinForms;
using System.Data;
using System.Data.ADO;
//Using System.IO;

public class DataAccess{

	private static string	strCon="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\Learning.net\\DataAccess\\Biblio.MDB";


	public static void Main(){


		
		//string	strCon="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Biblio.MDB";
		
		//string	strCon="\\";

		ADOConnection mCon=new ADOConnection(strCon);
		ADOCommand myCmd = new ADOCommand("Select * from authors", mCon);
		ADODataReader myReader=null;
	
		try{
			mCon.Open();
			myCmd.Execute(out myReader);
			if (myReader!=null)
				while (myReader.Read())
					Console.WriteLine("author name: {0}", myReader["author"]);
		}
		catch(Exception e){
			//System.WinForms.MessageBox.Show(e.ToString());
			MessageBox.Show(e.ToString());
			//Console.WriteLine(e.ToString());
		}

		finally{
			if (mCon.State==DBObjectState.Open)
				mCon.Close();
			if(null!=myReader)
				myReader=null;		
		}
		
		DataAccess DA =new DataAccess();

		DA.GetDataSet();
		DA.ReadAndDisplayXml();

	}
	

	 private void GetDataSet(){

		ADOConnection mCon=new ADOConnection(strCon);
		DataSet myDS=new DataSet();
		ADODataSetCommand myDSCommand=new ADODataSetCommand("Select * from Authors",mCon);	
		myDSCommand.FillDataSet(myDS,"Authors");
		myDSCommand.FillDataSet(myDS,"Title Author");

		myDS.WriteXml("myXmlDoc.xml");
		
		foreach(DataRow myAuthor in myDS.Tables[0].Rows)
			Console.WriteLine(myAuthor["Au_ID"].ToString());
		
		myDS.Relations.Add("AuthorIsbn",myDS.Tables["Authors"].Columns["Au_ID"],myDS.Tables["Title Author"].Columns["Au_ID"]);
		DataRow Au=myDS.Tables["Authors"].Rows[0];
		DataRow[] isbn=Au.GetChildRows(myDS.Relations["AuthorIsbn"]);
		Console.WriteLine("Total Child records for Authors Relationship = " +isbn.Length.ToString());
			
	}

	private void ReadAndDisplayXml(){

		System.IO.FileStream fsReadXml = new System.IO.FileStream("myxmldoc.xml",System.IO.FileMode.Open);
		DataSet ds = new DataSet();
		ds.ReadXml(fsReadXml);
		
		foreach(DataTable myTable in ds.Tables)
			Console.WriteLine(myTable.TableName);

	}

}