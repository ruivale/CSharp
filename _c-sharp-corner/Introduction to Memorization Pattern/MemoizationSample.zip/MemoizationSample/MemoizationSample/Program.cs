﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MemoizationSample
{
    class Program
    {
        static Hashtable prevResults = new Hashtable();
            
        static void Main(string[] args)
        {
            int n = 0;
            try
            {
                do
                {
                    Console.WriteLine("Enter n value");
                    n = Convert.ToInt32(Console.ReadLine());
                    int sum = SumofNumbers(n);
                    Console.WriteLine("Sum of n Numbers: " + sum.ToString());
                } while (n!= -1);
            }
            catch { }
        }
        private static int SumofNumbers(int n)
        {
            if (prevResults.Contains(n))
            {
                Console.WriteLine("From Cache");
                return Convert.ToInt32(prevResults[n].ToString());
            }
            int temp=0;
            for (int i = 1; i <= n; i++)
            {
                temp += i;
            }
            prevResults.Add(n, temp);
            return temp;
        }
    }
}
