/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ZipFramework;

/**
 *
 * @author Neill Harper
 */
public abstract class HeaderBase extends ZIPObject {

    public abstract int getSignature();
    
    
}
