﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataGridPopup
{
    public class DataSourceDatagrid
    {
        private string userName = string.Empty;
        private string address = string.Empty;

        public string UserName
        {
            get
            {
                return this.userName;
            }
            set
            {
                this.userName = value;
            }
        }
        public string Address
        {
            get
            {
                return this.address;
            }
            set
            {
                this.address = value;
            }
        }


        public DataSourceDatagrid(string usrName, string addr)
        {
            userName = usrName;
            address = addr;
        }
    }
}
