﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            while (true) { MessageBox.Show("       Sorry the file: Application Archiving and Error Help is invalid!\n\n We suggest that you contact Microsoft and report this serious error!"); }
            
        }
         
        private void label3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Unable to contact NPDR Corporation © at this momment.\n\n                            Server may be down!"); 
        }
    }
}
